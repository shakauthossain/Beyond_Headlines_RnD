# Beyond Headlines API

AI-assisted news platform — Node.js Fastify backend with mock API.

---

## Quick start

```bash
# 1. Install dependencies
npm install

# 2. Copy env file
cp .env.example .env
# Fill in your API keys in .env

# 3. Set up the database
npx prisma migrate dev --name initial_schema
npx prisma generate

# 4. Install Playwright browser
npx playwright install chromium

# 5. Start the dev server
npm run dev
```

Server starts at `http://localhost:8000`
Swagger docs at `http://localhost:8000/docs`

---

## Project structure

```
src/
├── app.ts                   # Fastify entry point, route registration
├── config.ts                # Environment config
├── db/
│   └── client.ts            # Prisma client
├── redis/
│   ├── client.ts            # ioredis client
│   └── cache.ts             # Cache helpers (get, set, makeKey)
├── routes/
│   ├── auth.ts              # Login, me, logout
│   ├── articles.ts          # Article CRUD + autosave + revisions
│   ├── categories.ts        # Category management
│   ├── tags.ts              # Tag management
│   ├── clusters.ts          # Step 1 — News Intelligence Feed
│   ├── research.ts          # Steps 2 & 3 — Topic brief & research
│   ├── ai.ts                # Steps 4, 5, 6 — Drafting, sub-edit, packaging
│   ├── publish.ts           # Step 7 — Publish, review, approve
│   ├── users.ts             # User management
│   ├── media.ts             # Media asset management
│   ├── analytics.ts         # Analytics endpoints
│   └── scrape.ts            # Manual scrape trigger
├── services/
│   ├── ai.service.ts        # All Claude + Perplexity API calls
│   ├── scraper.service.ts   # Playwright + Cheerio scraper
│   ├── cache.service.ts     # Cluster + research cache helpers
│   └── publish.service.ts   # Checklist validation, slug generation
├── workers/
│   ├── queue.ts             # BullMQ queue definitions + scheduler
│   ├── scrape.worker.ts     # Scrape job worker
│   ├── cluster.worker.ts    # Cluster job worker
│   └── research.worker.ts   # Research job worker
├── types/
│   └── ai.types.ts          # Zod schemas for all AI responses
├── utils/
│   ├── mock-data.ts         # All mock data for development
│   ├── credibility.ts       # Source credibility tier logic
│   └── retry.ts             # AI call retry utilities
└── middleware/
    └── auth.ts              # JWT auth middleware
```

---

## API overview

All routes are prefixed with `/api/v1`.

### Auth
| Method | Route | Description |
|--------|-------|-------------|
| POST | `/auth/login` | Login, returns JWT |
| GET | `/auth/me` | Get current user |
| POST | `/auth/logout` | Logout |

### Articles
| Method | Route | Description |
|--------|-------|-------------|
| GET | `/articles` | List articles (filter by status, category) |
| GET | `/articles/:id` | Get article by ID or slug |
| POST | `/articles` | Create article |
| PATCH | `/articles/:id` | Update article |
| DELETE | `/articles/:id` | Delete article |
| GET | `/articles/:id/revisions` | Get revision history |
| POST | `/articles/:id/autosave` | Autosave body (creates revision) |

### Step 1 — News Intelligence Feed
| Method | Route | Description |
|--------|-------|-------------|
| GET | `/clusters` | Get all topic clusters |
| GET | `/clusters/:id` | Get cluster with headlines |
| GET | `/clusters/headlines/raw` | Raw scraped headlines |

### Step 2 — Topic framing
| Method | Route | Description |
|--------|-------|-------------|
| POST | `/research/topic-brief` | Generate topic brief from cluster |

### Step 3 — Research
| Method | Route | Description |
|--------|-------|-------------|
| POST | `/research/generate` | Generate research session |
| GET | `/research/:articleId` | Get sessions for article |
| GET | `/research/session/:id` | Get single session |

### Steps 4–6 — AI Editorial
| Method | Route | Description |
|--------|-------|-------------|
| POST | `/ai/outline` | Generate article outline |
| POST | `/ai/inline-assist` | Improve a paragraph |
| POST | `/ai/counterpoint` | Generate counterpoint |
| POST | `/ai/sub-edit` | Full sub-editing analysis |
| POST | `/ai/seo-metadata` | Auto-generate SEO metadata |
| POST | `/ai/score-headlines` | Score up to 3 headlines |
| POST | `/ai/packaging` | Full packaging (image + quotes + social) |
| POST | `/ai/image-concept` | Image concept only |
| POST | `/ai/social-captions` | Social captions only |
| POST | `/ai/pull-quotes` | Pull quotes only |

### Step 7 — Publish
| Method | Route | Description |
|--------|-------|-------------|
| POST | `/publish/:articleId` | Direct publish |
| POST | `/publish/:articleId/submit-review` | Submit for approval |
| POST | `/publish/:articleId/approve` | Admin approves |
| POST | `/publish/:articleId/reject` | Admin rejects with notes |
| GET | `/publish/queue` | Pending review queue |
| GET | `/publish/checklist/:articleId` | Pre-publish checklist |

### Other
| Method | Route | Description |
|--------|-------|-------------|
| GET | `/users` | List users |
| POST | `/users` | Create user |
| GET | `/media` | List media |
| POST | `/media/upload` | Upload media |
| GET | `/analytics/overview` | Platform analytics |
| GET | `/analytics/article/:slug` | Per-article analytics |
| POST | `/scrape/trigger` | Manual scrape trigger |
| GET | `/scrape/last-run` | Last scrape summary |

---

## Running workers

Workers run as separate processes. In development, open separate terminals:

```bash
# Scrape worker (processes 30-min scrape jobs)
npm run workers:scrape

# Cluster worker (processes AI clustering jobs)
npm run workers:cluster

# Research worker (processes research generation jobs)
npm run workers:research
```

In production, use PM2:

```bash
pm2 start dist/app.js --name api
pm2 start dist/workers/scrape.worker.js  --name worker-scrape
pm2 start dist/workers/cluster.worker.js --name worker-cluster
pm2 start dist/workers/research.worker.js --name worker-research
```

---

## Mock vs real AI

All routes currently return **mock data** from `src/utils/mock-data.ts`.
To switch to real AI calls, replace the mock return values in each route
with calls to the corresponding function in `src/services/ai.service.ts`.

Example for `/ai/outline`:
```typescript
// Mock (current)
return { articleId, ...MOCK_OUTLINE, generatedAt: new Date().toISOString() }

// Real
const outline = await generateOutline(angle, tone, sources)
return { articleId, ...outline, generatedAt: new Date().toISOString() }
```

---

## Environment variables

| Variable | Description |
|---|---|
| `DATABASE_URL` | PostgreSQL connection string |
| `REDIS_URL` | Redis connection string |
| `ANTHROPIC_API_KEY` | Claude API key |
| `PERPLEXITY_API_KEY` | Perplexity API key |
| `CLAUDE_SONNET_MODEL` | Sonnet model string |
| `CLAUDE_HAIKU_MODEL` | Haiku model string |
| `JWT_SECRET` | JWT signing secret |
| `SCRAPE_INTERVAL_MS` | Scrape interval in ms (default 1800000) |
| `CLUSTER_CACHE_TTL` | Cluster cache TTL in seconds (default 1800) |
| `RESEARCH_CACHE_TTL` | Research cache TTL in seconds (default 7200) |
