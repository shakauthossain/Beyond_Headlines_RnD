import { z } from 'zod'

// ─── Enums ────────────────────────────────────────────────────────────────────
export const ArticleStatusEnum = z.enum(['DRAFT', 'PENDING_REVIEW', 'PUBLISHED', 'ARCHIVED'])
export const ToneEnum          = z.enum(['ANALYTICAL', 'CRITICAL', 'EXPLANATORY'])
export const UserRoleEnum      = z.enum(['ADMIN', 'EDITOR'])
export const SourceEnum        = z.enum(['PROTHOM_ALO', 'DAILY_STAR', 'BDNEWS24', 'JUGANTOR', 'DHAKA_TRIBUNE'])

// ─── AI Response Schemas ──────────────────────────────────────────────────────
export const ClusterSchema = z.object({
  topic:         z.string(),
  summary:       z.string(),
  sentiment:     z.string(),
  article_count: z.number(),
  is_emerging:   z.boolean().optional(),
})

export const TopicBriefSchema = z.object({
  issue_summary: z.string(),
  key_questions: z.array(z.string()),
  stakeholders:  z.array(z.object({ name: z.string(), role: z.string() })),
  viewpoints:    z.array(z.string()),
})

export const ResearchSynthesisSchema = z.object({
  timeline:    z.array(z.object({ date: z.string(), event: z.string(), source: z.string() })),
  data_points: z.array(z.string()),
  gaps:        z.array(z.string()),
})

export const SEOMetadataSchema = z.object({
  meta_title:       z.string(),
  meta_description: z.string(),
  tags:             z.array(z.string()),
})

export const SubEditSchema = z.object({
  clarity_issues: z.array(z.object({
    paragraph_index:   z.number(),
    issue_description: z.string(),
    suggested_fix:     z.string(),
  })),
  tone_issues: z.array(z.object({
    paragraph_index:   z.number(),
    issue_description: z.string(),
    suggested_fix:     z.string(),
  })),
  flow_issues: z.array(z.object({
    paragraph_index:   z.number(),
    issue_description: z.string(),
    suggested_fix:     z.string(),
  })),
})

export const HeadlineScoreSchema = z.object({
  headlines: z.array(z.object({
    headline:  z.string(),
    score:     z.number(),
    rationale: z.string(),
  })),
})

export const PackagingSchema = z.object({
  image_concept: z.string(),
  pull_quotes:   z.array(z.object({ quote: z.string(), paragraph_index: z.number() })),
  social_captions: z.object({
    twitter:  z.string(),
    linkedin: z.string(),
    whatsapp: z.string(),
  }),
})

export const OutlineSchema = z.object({
  sections: z.array(z.object({
    label:     z.string(),
    direction: z.string(),
  })),
})

export const InlineAssistSchema = z.object({
  original:  z.string(),
  suggested: z.string(),
  rationale: z.string(),
})

export const CounterpointSchema = z.object({
  counterpoint: z.string(),
  supporting_points: z.array(z.string()),
})

// ─── Request/Response Schemas ─────────────────────────────────────────────────
export const LoginSchema = z.object({
  email:    z.string().email(),
  password: z.string().min(6),
})

export const CreateArticleSchema = z.object({
  title:      z.string().min(1),
  body:       z.any().optional(),
  categoryId: z.string().uuid().optional(),
  tone:       ToneEnum.optional(),
  angle:      z.string().optional(),
})

export const UpdateArticleSchema = CreateArticleSchema.partial().extend({
  metaTitle:       z.string().optional(),
  metaDescription: z.string().optional(),
  tags:            z.array(z.string()).optional(),
})

export const ResearchRequestSchema = z.object({
  articleId: z.string().uuid(),
  angle:     z.string().min(5),
})

export const SubEditRequestSchema = z.object({
  articleId: z.string().uuid(),
})

export const HeadlineScoreRequestSchema = z.object({
  headlines: z.array(z.string()).min(1).max(3),
})

export const InlineAssistRequestSchema = z.object({
  articleId:  z.string().uuid(),
  paragraph:  z.string(),
  tone:       ToneEnum.optional(),
})

export const CounterpointRequestSchema = z.object({
  articleId:  z.string().uuid(),
  paragraph:  z.string(),
})

export const PackagingRequestSchema = z.object({
  articleId: z.string().uuid(),
})

export const TopicBriefRequestSchema = z.object({
  clusterId: z.string().uuid(),
})

// ─── Types ────────────────────────────────────────────────────────────────────
export type ClusterOutput           = z.infer<typeof ClusterSchema>
export type TopicBriefOutput        = z.infer<typeof TopicBriefSchema>
export type ResearchSynthesisOutput = z.infer<typeof ResearchSynthesisSchema>
export type SEOMetadataOutput       = z.infer<typeof SEOMetadataSchema>
export type SubEditOutput           = z.infer<typeof SubEditSchema>
export type PackagingOutput         = z.infer<typeof PackagingSchema>
export type OutlineOutput           = z.infer<typeof OutlineSchema>
