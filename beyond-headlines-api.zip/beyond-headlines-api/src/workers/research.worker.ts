import { Worker } from 'bullmq'
import { redis } from '../redis/client'
import { searchPerplexity, synthesiseResearch } from '../services/ai.service'
import { setCachedResearch, getCachedResearch } from '../services/cache.service'
import { getCredibilityTier } from '../utils/credibility'

const researchWorker = new Worker(
  'research',
  async (job) => {
    const { articleId, angle } = job.data as { articleId: string; angle: string }
    console.log(`[Research Worker] Starting research for article: ${articleId}`)

    // Check cache first
    const cached = await getCachedResearch(angle)
    if (cached) {
      console.log('[Research Worker] Cache hit — returning cached research')
      return { ...cached, fromCache: true }
    }

    // Fetch from Perplexity
    const rawSources = await searchPerplexity(angle)
    const sources = rawSources.map((s: any) => ({
      ...s,
      credibility_tier: getCredibilityTier(s.url || ''),
    }))

    // Synthesise with Haiku
    const synthesis = await synthesiseResearch(angle, sources)

    const result = {
      articleId,
      angle,
      sources,
      timeline:    synthesis.timeline,
      data_points: synthesis.data_points,
      gaps:        synthesis.gaps,
      createdAt:   new Date().toISOString(),
    }

    await setCachedResearch(angle, result)
    console.log(`[Research Worker] Research complete for article: ${articleId}`)
    return result
  },
  {
    connection: redis,
    concurrency: 3,
  }
)

researchWorker.on('completed', (job, result) => {
  console.log(`[Research Worker] Job ${job.id} completed`)
})

researchWorker.on('failed', (job, err) => {
  console.error(`[Research Worker] Job ${job?.id} failed:`, err.message)
})

export default researchWorker
