import { Queue } from 'bullmq'
import { redis } from '../redis/client'
import { config } from '../config'

export const scrapeQueue   = new Queue('scrape',   { connection: redis })
export const clusterQueue  = new Queue('cluster',  { connection: redis })
export const researchQueue = new Queue('research', { connection: redis })

export const registerScheduledJobs = async () => {
  try {
    // Remove any existing repeatable jobs first to avoid duplicates on restart
    const existingJobs = await scrapeQueue.getRepeatableJobs()
    for (const job of existingJobs) {
      await scrapeQueue.removeRepeatableByKey(job.key)
    }

    // Register the 30-minute scrape cycle
    await scrapeQueue.add(
      'scrape-all-sources',
      { sources: ['PROTHOM_ALO', 'DAILY_STAR', 'BDNEWS24', 'JUGANTOR', 'DHAKA_TRIBUNE'] },
      {
        repeat: { every: config.SCRAPE_INTERVAL_MS },
        jobId:  'scrape-scheduled',
      }
    )

    console.log(`Scrape job scheduled every ${config.SCRAPE_INTERVAL_MS / 60000} minutes`)
  } catch (err) {
    console.error('Failed to register scheduled jobs:', err)
    // Non-fatal — server still starts without scheduling
  }
}

export const triggerScrapeNow = async (sources?: string[]) => {
  return scrapeQueue.add(
    'scrape-manual',
    { sources: sources || ['PROTHOM_ALO', 'DAILY_STAR', 'BDNEWS24', 'JUGANTOR', 'DHAKA_TRIBUNE'] },
    { jobId: `scrape-manual-${Date.now()}` }
  )
}
