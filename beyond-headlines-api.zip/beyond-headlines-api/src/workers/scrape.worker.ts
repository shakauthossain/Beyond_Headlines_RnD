import { Worker } from 'bullmq'
import { redis } from '../redis/client'
import { scrapeAllSources, scrapeSource } from '../services/scraper.service'
import { clusterQueue } from './queue'

const scrapeWorker = new Worker(
  'scrape',
  async (job) => {
    const { sources } = job.data as { sources?: string[] }
    console.log(`[Scrape Worker] Starting job: ${job.id}`)

    let items
    if (sources && sources.length < 5) {
      // Targeted scrape for specific sources
      const results = await Promise.allSettled(sources.map(scrapeSource))
      items = results
        .filter((r): r is PromiseFulfilledResult<any> => r.status === 'fulfilled')
        .flatMap(r => r.value)
    } else {
      items = await scrapeAllSources()
    }

    const headlines = items.map((i: any) => i.headline)
    console.log(`[Scrape Worker] Scraped ${items.length} headlines`)

    // Dispatch clustering job
    await clusterQueue.add('run-clustering', { headlines, rawItems: items })

    return { headlineCount: items.length, sources: sources || 'all' }
  },
  {
    connection: redis,
    concurrency: 1, // Only one scrape at a time
  }
)

scrapeWorker.on('completed', (job, result) => {
  console.log(`[Scrape Worker] Job ${job.id} completed:`, result)
})

scrapeWorker.on('failed', (job, err) => {
  console.error(`[Scrape Worker] Job ${job?.id} failed:`, err.message)
})

export default scrapeWorker
