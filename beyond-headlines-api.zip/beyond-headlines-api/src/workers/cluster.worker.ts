import { Worker } from 'bullmq'
import { redis } from '../redis/client'
import { clusterHeadlines } from '../services/ai.service'
import { setCachedCluster } from '../services/cache.service'

const clusterWorker = new Worker(
  'cluster',
  async (job) => {
    const { headlines, rawItems } = job.data as { headlines: string[]; rawItems: object[] }
    console.log(`[Cluster Worker] Clustering ${headlines.length} headlines`)

    // Check if we have enough headlines to cluster
    if (!headlines || headlines.length < 3) {
      console.log('[Cluster Worker] Not enough headlines to cluster')
      return { clustered: false, reason: 'insufficient headlines' }
    }

    const clusters = await clusterHeadlines(headlines)
    await setCachedCluster(headlines, clusters)

    console.log(`[Cluster Worker] Created ${clusters.length} clusters`)
    return { clusterCount: clusters.length, headlineCount: headlines.length }
  },
  {
    connection: redis,
    concurrency: 2,
  }
)

clusterWorker.on('completed', (job, result) => {
  console.log(`[Cluster Worker] Job ${job.id} completed:`, result)
})

clusterWorker.on('failed', (job, err) => {
  console.error(`[Cluster Worker] Job ${job?.id} failed:`, err.message)
})

export default clusterWorker
