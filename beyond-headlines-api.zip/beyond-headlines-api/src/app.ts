import Fastify from 'fastify'
import cors from '@fastify/cors'
import jwt from '@fastify/jwt'
import swagger from '@fastify/swagger'
import swaggerUi from '@fastify/swagger-ui'
import { config } from './config'
import { authRoutes } from './routes/auth'
import { articleRoutes } from './routes/articles'
import { categoryRoutes } from './routes/categories'
import { tagRoutes } from './routes/tags'
import { clusterRoutes } from './routes/clusters'
import { researchRoutes } from './routes/research'
import { aiRoutes } from './routes/ai'
import { mediaRoutes } from './routes/media'
import { userRoutes } from './routes/users'
import { publishRoutes } from './routes/publish'
import { analyticsRoutes } from './routes/analytics'
import { scrapeRoutes } from './routes/scrape'
import { registerScheduledJobs } from './workers/queue'

const app = Fastify({ logger: true })

// Plugins
app.register(cors, { origin: true })
app.register(jwt, { secret: config.JWT_SECRET })

// Swagger docs
app.register(swagger, {
  openapi: {
    info: {
      title: 'Beyond Headlines API',
      description: 'AI-assisted news platform — mock API',
      version: '1.0.0',
    },
    components: {
      securitySchemes: {
        bearerAuth: { type: 'http', scheme: 'bearer', bearerFormat: 'JWT' },
      },
    },
  },
})
app.register(swaggerUi, { routePrefix: '/docs' })

// Routes
app.register(authRoutes,      { prefix: '/api/v1/auth' })
app.register(userRoutes,      { prefix: '/api/v1/users' })
app.register(articleRoutes,   { prefix: '/api/v1/articles' })
app.register(categoryRoutes,  { prefix: '/api/v1/categories' })
app.register(tagRoutes,       { prefix: '/api/v1/tags' })
app.register(clusterRoutes,   { prefix: '/api/v1/clusters' })
app.register(researchRoutes,  { prefix: '/api/v1/research' })
app.register(aiRoutes,        { prefix: '/api/v1/ai' })
app.register(mediaRoutes,     { prefix: '/api/v1/media' })
app.register(publishRoutes,   { prefix: '/api/v1/publish' })
app.register(analyticsRoutes, { prefix: '/api/v1/analytics' })
app.register(scrapeRoutes,    { prefix: '/api/v1/scrape' })

// Health check
app.get('/health', async () => ({ status: 'ok', timestamp: new Date().toISOString() }))

// Start server
const start = async () => {
  try {
    await registerScheduledJobs()
    await app.listen({ port: config.PORT, host: '0.0.0.0' })
    console.log(`Server running on port ${config.PORT}`)
    console.log(`Swagger docs at http://localhost:${config.PORT}/docs`)
  } catch (err) {
    app.log.error(err)
    process.exit(1)
  }
}

start()
