import { FastifyInstance } from 'fastify'
import { MOCK_ANALYTICS } from '../utils/mock-data'

export async function analyticsRoutes(app: FastifyInstance) {

  // GET /api/v1/analytics/overview
  app.get('/overview', {
    schema: {
      tags: ['Analytics'],
      summary: 'Platform analytics overview',
      security: [{ bearerAuth: [] }],
    },
  }, async () => MOCK_ANALYTICS.overview)

  // GET /api/v1/analytics/top-articles
  app.get('/top-articles', {
    schema: {
      tags: ['Analytics'],
      summary: 'Top performing articles',
      security: [{ bearerAuth: [] }],
      querystring: {
        type: 'object',
        properties: {
          limit: { type: 'integer', default: 10 },
        },
      },
    },
  }, async () => ({ data: MOCK_ANALYTICS.topArticles }))

  // GET /api/v1/analytics/traffic
  app.get('/traffic', {
    schema: {
      tags: ['Analytics'],
      summary: 'Daily traffic data',
      security: [{ bearerAuth: [] }],
      querystring: {
        type: 'object',
        properties: {
          from: { type: 'string', description: 'ISO date e.g. 2026-04-01' },
          to:   { type: 'string', description: 'ISO date e.g. 2026-04-07' },
        },
      },
    },
  }, async () => ({ data: MOCK_ANALYTICS.trafficByDay }))

  // GET /api/v1/analytics/article/:slug
  app.get('/article/:slug', {
    schema: {
      tags: ['Analytics'],
      summary: 'Analytics for a specific article slug',
      security: [{ bearerAuth: [] }],
      params: { type: 'object', properties: { slug: { type: 'string' } } },
    },
  }, async (request) => {
    const { slug } = request.params as { slug: string }
    return {
      slug,
      views:       4210,
      uniqueViews: 3100,
      avgReadTime: '5m 12s',
      bounceRate:  '34%',
      referrers: [
        { source: 'Direct',  visits: 1800 },
        { source: 'Twitter', visits:  940 },
        { source: 'Google',  visits: 1470 },
      ],
      byDay: MOCK_ANALYTICS.trafficByDay,
    }
  })
}
