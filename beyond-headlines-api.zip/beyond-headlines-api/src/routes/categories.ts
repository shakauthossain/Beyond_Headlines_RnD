import { FastifyInstance } from 'fastify'
import { MOCK_CATEGORIES } from '../utils/mock-data'

let categories = [...MOCK_CATEGORIES]

export async function categoryRoutes(app: FastifyInstance) {

  // GET /api/v1/categories
  app.get('/', {
    schema: {
      tags: ['Categories'],
      summary: 'List all categories',
    },
  }, async () => categories)

  // GET /api/v1/categories/:id
  app.get('/:id', {
    schema: {
      tags: ['Categories'],
      summary: 'Get category by ID or slug',
      params: { type: 'object', properties: { id: { type: 'string' } } },
    },
  }, async (request, reply) => {
    const { id } = request.params as { id: string }
    const cat = categories.find(c => c.id === id || c.slug === id)
    if (!cat) return reply.status(404).send({ error: 'Category not found' })
    return cat
  })

  // POST /api/v1/categories
  app.post('/', {
    schema: {
      tags: ['Categories'],
      summary: 'Create category',
      security: [{ bearerAuth: [] }],
      body: {
        type: 'object',
        required: ['name', 'slug'],
        properties: {
          name:        { type: 'string' },
          slug:        { type: 'string' },
          description: { type: 'string' },
          parentId:    { type: 'string' },
        },
      },
    },
  }, async (request, reply) => {
    const body = request.body as any
    const newCat = { id: `cat-${Date.now()}`, ...body, parentId: body.parentId || null }
    categories.push(newCat)
    return reply.status(201).send(newCat)
  })

  // PATCH /api/v1/categories/:id
  app.patch('/:id', {
    schema: {
      tags: ['Categories'],
      summary: 'Update category',
      security: [{ bearerAuth: [] }],
      params: { type: 'object', properties: { id: { type: 'string' } } },
    },
  }, async (request, reply) => {
    const { id } = request.params as { id: string }
    const idx = categories.findIndex(c => c.id === id)
    if (idx === -1) return reply.status(404).send({ error: 'Category not found' })
    categories[idx] = { ...categories[idx], ...(request.body as any) }
    return categories[idx]
  })

  // DELETE /api/v1/categories/:id
  app.delete('/:id', {
    schema: {
      tags: ['Categories'],
      summary: 'Delete category',
      security: [{ bearerAuth: [] }],
      params: { type: 'object', properties: { id: { type: 'string' } } },
    },
  }, async (request, reply) => {
    const { id } = request.params as { id: string }
    const idx = categories.findIndex(c => c.id === id)
    if (idx === -1) return reply.status(404).send({ error: 'Category not found' })
    categories.splice(idx, 1)
    return reply.status(204).send()
  })
}
