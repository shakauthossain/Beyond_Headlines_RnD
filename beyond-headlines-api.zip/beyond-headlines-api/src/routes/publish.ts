import { FastifyInstance } from 'fastify'

export async function publishRoutes(app: FastifyInstance) {

  // POST /api/v1/publish/:articleId
  // Step 7 — Direct publish
  app.post('/:articleId', {
    schema: {
      tags: ['Publish — Step 7'],
      summary: 'Publish article directly (Editor role)',
      security: [{ bearerAuth: [] }],
      params: { type: 'object', properties: { articleId: { type: 'string' } } },
    },
  }, async (request, reply) => {
    const { articleId } = request.params as { articleId: string }
    const checklist = _validateChecklist(request.body as any)
    if (!checklist.valid) {
      return reply.status(422).send({
        error:    'Pre-publish checklist failed',
        missing:  checklist.missing,
      })
    }
    return {
      articleId,
      status:      'PUBLISHED',
      slug:        'article-slug-here',
      publishedAt: new Date().toISOString(),
      url:         `https://beyondheadlines.com/articles/article-slug-here`,
    }
  })

  // POST /api/v1/publish/:articleId/submit-review
  // Step 7 — Submit for editor approval
  app.post('/:articleId/submit-review', {
    schema: {
      tags: ['Publish — Step 7'],
      summary: 'Submit article for editor review',
      security: [{ bearerAuth: [] }],
      params: { type: 'object', properties: { articleId: { type: 'string' } } },
    },
  }, async (request) => {
    const { articleId } = request.params as { articleId: string }
    return {
      articleId,
      status:      'PENDING_REVIEW',
      submittedAt: new Date().toISOString(),
      message:     'Article submitted for review. Admin will be notified.',
    }
  })

  // POST /api/v1/publish/:articleId/approve
  // Admin approves and publishes
  app.post('/:articleId/approve', {
    schema: {
      tags: ['Publish — Step 7'],
      summary: 'Approve and publish article (Admin role)',
      security: [{ bearerAuth: [] }],
      params: { type: 'object', properties: { articleId: { type: 'string' } } },
    },
  }, async (request) => {
    const { articleId } = request.params as { articleId: string }
    return {
      articleId,
      status:      'PUBLISHED',
      approvedBy:  'user-admin-001',
      publishedAt: new Date().toISOString(),
      url:         `https://beyondheadlines.com/articles/article-slug-here`,
    }
  })

  // POST /api/v1/publish/:articleId/reject
  // Admin rejects and returns with notes
  app.post('/:articleId/reject', {
    schema: {
      tags: ['Publish — Step 7'],
      summary: 'Reject article and return with notes (Admin role)',
      security: [{ bearerAuth: [] }],
      params: { type: 'object', properties: { articleId: { type: 'string' } } },
      body: {
        type: 'object',
        required: ['notes'],
        properties: {
          notes: { type: 'string' },
        },
      },
    },
  }, async (request) => {
    const { articleId } = request.params as { articleId: string }
    const { notes } = request.body as { notes: string }
    return {
      articleId,
      status:     'DRAFT',
      rejectedBy: 'user-admin-001',
      notes,
      rejectedAt: new Date().toISOString(),
    }
  })

  // GET /api/v1/publish/queue
  // CMS queue of pending review articles
  app.get('/queue', {
    schema: {
      tags: ['Publish — Step 7'],
      summary: 'Get articles pending review (Admin queue)',
      security: [{ bearerAuth: [] }],
    },
  }, async () => {
    return {
      data: [
        {
          id:          'art-queue-001',
          title:       'Fuel subsidies and the politics of energy reform',
          status:      'PENDING_REVIEW',
          submittedAt: new Date().toISOString(),
          author:      { id: 'user-editor-001', name: 'Editorial Analyst' },
        },
      ],
      total: 1,
    }
  })

  // GET /api/v1/publish/checklist/:articleId
  // Pre-publish checklist validation
  app.get('/checklist/:articleId', {
    schema: {
      tags: ['Publish — Step 7'],
      summary: 'Get pre-publish checklist status for article',
      security: [{ bearerAuth: [] }],
      params: { type: 'object', properties: { articleId: { type: 'string' } } },
    },
  }, async (request) => {
    const { articleId } = request.params as { articleId: string }
    return {
      articleId,
      checklist: {
        titleSet:        { passed: true,  label: 'Headline set' },
        metaDescription: { passed: false, label: 'Meta description filled' },
        imageConcept:    { passed: true,  label: 'Feature image concept saved' },
        tagsAdded:       { passed: false, label: 'At least one tag added' },
      },
      ready: false,
    }
  })
}

function _validateChecklist(body: any) {
  const missing: string[] = []
  // In mock, always pass unless body explicitly marks failures
  if (body?.forceChecklistFail) {
    missing.push('metaDescription', 'tags')
  }
  return { valid: missing.length === 0, missing }
}
