import { FastifyInstance } from 'fastify'
import { MOCK_TAGS } from '../utils/mock-data'

let tags = [...MOCK_TAGS]

export async function tagRoutes(app: FastifyInstance) {

  // GET /api/v1/tags
  app.get('/', {
    schema: { tags: ['Tags'], summary: 'List all tags' },
  }, async () => tags)

  // POST /api/v1/tags
  app.post('/', {
    schema: {
      tags: ['Tags'],
      summary: 'Create tag',
      security: [{ bearerAuth: [] }],
      body: {
        type: 'object',
        required: ['name', 'slug'],
        properties: {
          name: { type: 'string' },
          slug: { type: 'string' },
        },
      },
    },
  }, async (request, reply) => {
    const body = request.body as any
    const newTag = { id: `tag-${Date.now()}`, ...body }
    tags.push(newTag)
    return reply.status(201).send(newTag)
  })

  // DELETE /api/v1/tags/:id
  app.delete('/:id', {
    schema: {
      tags: ['Tags'],
      summary: 'Delete tag',
      security: [{ bearerAuth: [] }],
      params: { type: 'object', properties: { id: { type: 'string' } } },
    },
  }, async (request, reply) => {
    const { id } = request.params as { id: string }
    const idx = tags.findIndex(t => t.id === id)
    if (idx === -1) return reply.status(404).send({ error: 'Tag not found' })
    tags.splice(idx, 1)
    return reply.status(204).send()
  })
}
