import { FastifyInstance } from 'fastify'
import { MOCK_MEDIA } from '../utils/mock-data'

let media = [...MOCK_MEDIA]

export async function mediaRoutes(app: FastifyInstance) {

  // GET /api/v1/media
  app.get('/', {
    schema: {
      tags: ['Media'],
      summary: 'List all media assets',
      security: [{ bearerAuth: [] }],
      querystring: {
        type: 'object',
        properties: {
          mimeType: { type: 'string' },
          page:     { type: 'integer', default: 1 },
          limit:    { type: 'integer', default: 20 },
        },
      },
    },
  }, async (request) => {
    const { mimeType, page = 1, limit = 20 } = request.query as any
    let result = [...media]
    if (mimeType) result = result.filter(m => m.mimeType.includes(mimeType))
    const start = (page - 1) * limit
    return { data: result.slice(start, start + limit), total: result.length, page, limit }
  })

  // GET /api/v1/media/:id
  app.get('/:id', {
    schema: {
      tags: ['Media'],
      summary: 'Get media asset by ID',
      security: [{ bearerAuth: [] }],
      params: { type: 'object', properties: { id: { type: 'string' } } },
    },
  }, async (request, reply) => {
    const { id } = request.params as { id: string }
    const asset = media.find(m => m.id === id)
    if (!asset) return reply.status(404).send({ error: 'Media not found' })
    return asset
  })

  // POST /api/v1/media/upload
  app.post('/upload', {
    schema: {
      tags: ['Media'],
      summary: 'Upload media asset (mock — returns a fake CDN URL)',
      security: [{ bearerAuth: [] }],
      body: {
        type: 'object',
        required: ['filename', 'mimeType'],
        properties: {
          filename: { type: 'string' },
          mimeType: { type: 'string' },
          alt:      { type: 'string' },
          size:     { type: 'number' },
        },
      },
    },
  }, async (request, reply) => {
    const body = request.body as any
    const newAsset = {
      id:         `media-${Date.now()}`,
      filename:   body.filename,
      url:        `https://cdn.beyondheadlines.com/uploads/${Date.now()}-${body.filename}`,
      mimeType:   body.mimeType,
      size:       body.size || 0,
      alt:        body.alt || null,
      uploadedAt: new Date().toISOString(),
    }
    media.push(newAsset)
    return reply.status(201).send(newAsset)
  })

  // PATCH /api/v1/media/:id
  app.patch('/:id', {
    schema: {
      tags: ['Media'],
      summary: 'Update media asset metadata',
      security: [{ bearerAuth: [] }],
      params: { type: 'object', properties: { id: { type: 'string' } } },
      body: {
        type: 'object',
        properties: {
          alt:      { type: 'string' },
          filename: { type: 'string' },
        },
      },
    },
  }, async (request, reply) => {
    const { id } = request.params as { id: string }
    const idx = media.findIndex(m => m.id === id)
    if (idx === -1) return reply.status(404).send({ error: 'Media not found' })
    media[idx] = { ...media[idx], ...(request.body as any) }
    return media[idx]
  })

  // DELETE /api/v1/media/:id
  app.delete('/:id', {
    schema: {
      tags: ['Media'],
      summary: 'Delete media asset',
      security: [{ bearerAuth: [] }],
      params: { type: 'object', properties: { id: { type: 'string' } } },
    },
  }, async (request, reply) => {
    const { id } = request.params as { id: string }
    const idx = media.findIndex(m => m.id === id)
    if (idx === -1) return reply.status(404).send({ error: 'Media not found' })
    media.splice(idx, 1)
    return reply.status(204).send()
  })
}
