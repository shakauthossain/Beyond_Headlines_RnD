import { FastifyInstance } from 'fastify'
import { MOCK_USERS } from '../utils/mock-data'

let users = [...MOCK_USERS]

export async function userRoutes(app: FastifyInstance) {

  // GET /api/v1/users
  app.get('/', {
    schema: {
      tags: ['Users'],
      summary: 'List all users',
      security: [{ bearerAuth: [] }],
    },
  }, async () => users.map(({ ...u }) => ({ ...u })))

  // GET /api/v1/users/:id
  app.get('/:id', {
    schema: {
      tags: ['Users'],
      summary: 'Get user by ID',
      security: [{ bearerAuth: [] }],
      params: { type: 'object', properties: { id: { type: 'string' } } },
    },
  }, async (request, reply) => {
    const { id } = request.params as { id: string }
    const user = users.find(u => u.id === id)
    if (!user) return reply.status(404).send({ error: 'User not found' })
    return user
  })

  // POST /api/v1/users
  app.post('/', {
    schema: {
      tags: ['Users'],
      summary: 'Create user (Admin only)',
      security: [{ bearerAuth: [] }],
      body: {
        type: 'object',
        required: ['email', 'name', 'role'],
        properties: {
          email:    { type: 'string', format: 'email' },
          name:     { type: 'string' },
          password: { type: 'string' },
          role:     { type: 'string', enum: ['ADMIN', 'EDITOR'] },
        },
      },
    },
  }, async (request, reply) => {
    const body = request.body as any
    const newUser = {
      id:        `user-${Date.now()}`,
      email:     body.email,
      name:      body.name,
      role:      body.role,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }
    users.push(newUser)
    return reply.status(201).send(newUser)
  })

  // PATCH /api/v1/users/:id
  app.patch('/:id', {
    schema: {
      tags: ['Users'],
      summary: 'Update user',
      security: [{ bearerAuth: [] }],
      params: { type: 'object', properties: { id: { type: 'string' } } },
    },
  }, async (request, reply) => {
    const { id } = request.params as { id: string }
    const idx = users.findIndex(u => u.id === id)
    if (idx === -1) return reply.status(404).send({ error: 'User not found' })
    users[idx] = { ...users[idx], ...(request.body as any), updatedAt: new Date().toISOString() }
    return users[idx]
  })

  // DELETE /api/v1/users/:id
  app.delete('/:id', {
    schema: {
      tags: ['Users'],
      summary: 'Delete user',
      security: [{ bearerAuth: [] }],
      params: { type: 'object', properties: { id: { type: 'string' } } },
    },
  }, async (request, reply) => {
    const { id } = request.params as { id: string }
    const idx = users.findIndex(u => u.id === id)
    if (idx === -1) return reply.status(404).send({ error: 'User not found' })
    users.splice(idx, 1)
    return reply.status(204).send()
  })
}
