import { FastifyInstance } from 'fastify'
import { MOCK_RESEARCH, MOCK_TOPIC_BRIEF } from '../utils/mock-data'

export async function researchRoutes(app: FastifyInstance) {

  // POST /api/v1/research/topic-brief
  // Step 2 — Topic selection & framing
  app.post('/topic-brief', {
    schema: {
      tags: ['Research — Step 2'],
      summary: 'Generate AI topic brief from a cluster',
      security: [{ bearerAuth: [] }],
      body: {
        type: 'object',
        required: ['clusterId'],
        properties: {
          clusterId: { type: 'string' },
        },
      },
    },
  }, async (request) => {
    const { clusterId } = request.body as { clusterId: string }
    // Mock: returns same brief regardless of cluster
    await delay(800) // simulate AI latency
    return {
      clusterId,
      ...MOCK_TOPIC_BRIEF,
      generatedAt: new Date().toISOString(),
    }
  })

  // POST /api/v1/research/generate
  // Step 3 — Deep research & context building
  app.post('/generate', {
    schema: {
      tags: ['Research — Step 3'],
      summary: 'Generate full research session for an article angle',
      security: [{ bearerAuth: [] }],
      body: {
        type: 'object',
        required: ['articleId', 'angle'],
        properties: {
          articleId: { type: 'string' },
          angle:     { type: 'string' },
        },
      },
    },
  }, async (request) => {
    const { articleId, angle } = request.body as { articleId: string; angle: string }
    await delay(1500) // simulate Perplexity + Haiku latency
    return {
      ...MOCK_RESEARCH,
      id:        `research-${Date.now()}`,
      articleId,
      angle,
      createdAt: new Date().toISOString(),
    }
  })

  // GET /api/v1/research/:articleId
  app.get('/:articleId', {
    schema: {
      tags: ['Research — Step 3'],
      summary: 'Get research sessions for an article',
      security: [{ bearerAuth: [] }],
      params: { type: 'object', properties: { articleId: { type: 'string' } } },
    },
  }, async (request) => {
    const { articleId } = request.params as { articleId: string }
    return {
      articleId,
      sessions: [{ ...MOCK_RESEARCH, articleId }],
    }
  })

  // GET /api/v1/research/session/:id
  app.get('/session/:id', {
    schema: {
      tags: ['Research — Step 3'],
      summary: 'Get a single research session by ID',
      security: [{ bearerAuth: [] }],
      params: { type: 'object', properties: { id: { type: 'string' } } },
    },
  }, async (request, reply) => {
    const { id } = request.params as { id: string }
    if (id === MOCK_RESEARCH.id) return MOCK_RESEARCH
    return reply.status(404).send({ error: 'Research session not found' })
  })
}

function delay(ms: number) {
  return new Promise(resolve => setTimeout(resolve, ms))
}
