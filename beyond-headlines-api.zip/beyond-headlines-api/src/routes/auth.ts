import { FastifyInstance } from 'fastify'
import { MOCK_USERS } from '../utils/mock-data'

export async function authRoutes(app: FastifyInstance) {

  // POST /api/v1/auth/login
  app.post('/login', {
    schema: {
      tags: ['Auth'],
      summary: 'Login and receive JWT token',
      body: {
        type: 'object',
        required: ['email', 'password'],
        properties: {
          email:    { type: 'string', format: 'email' },
          password: { type: 'string', minLength: 6 },
        },
      },
      response: {
        200: {
          type: 'object',
          properties: {
            token: { type: 'string' },
            user:  { type: 'object' },
          },
        },
      },
    },
  }, async (request, reply) => {
    const { email, password } = request.body as { email: string; password: string }
    const user = MOCK_USERS.find(u => u.email === email)
    if (!user) {
      return reply.status(401).send({ error: 'Invalid credentials' })
    }
    // Mock: any password works in dev
    const token = app.jwt.sign({ id: user.id, email: user.email, role: user.role })
    return { token, user: { id: user.id, email: user.email, name: user.name, role: user.role } }
  })

  // GET /api/v1/auth/me
  app.get('/me', {
    schema: {
      tags: ['Auth'],
      summary: 'Get current authenticated user',
      security: [{ bearerAuth: [] }],
    },
    preHandler: [app.authenticate],
  }, async (request) => {
    const payload = request.user as { id: string }
    const user = MOCK_USERS.find(u => u.id === payload.id) || MOCK_USERS[1]
    return user
  })

  // POST /api/v1/auth/logout
  app.post('/logout', {
    schema: {
      tags: ['Auth'],
      summary: 'Logout (client-side token discard)',
      security: [{ bearerAuth: [] }],
    },
  }, async () => {
    return { message: 'Logged out successfully' }
  })

  // Decorate app with authenticate helper
  app.decorate('authenticate', async function (request: any, reply: any) {
    try {
      await request.jwtVerify()
    } catch {
      reply.status(401).send({ error: 'Unauthorized' })
    }
  })
}
