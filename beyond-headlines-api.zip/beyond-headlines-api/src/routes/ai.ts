import { FastifyInstance } from 'fastify'
import {
  MOCK_OUTLINE,
  MOCK_INLINE_ASSIST,
  MOCK_COUNTERPOINT,
  MOCK_SUB_EDIT,
  MOCK_SEO_METADATA,
  MOCK_HEADLINE_SCORES,
  MOCK_PACKAGING,
} from '../utils/mock-data'

function delay(ms: number) {
  return new Promise(resolve => setTimeout(resolve, ms))
}

export async function aiRoutes(app: FastifyInstance) {

  // ─── Step 4: Drafting & Story Construction ────────────────────────────────

  // POST /api/v1/ai/outline
  app.post('/outline', {
    schema: {
      tags: ['AI — Step 4: Drafting'],
      summary: 'Generate article outline from confirmed angle and tone',
      security: [{ bearerAuth: [] }],
      body: {
        type: 'object',
        required: ['articleId'],
        properties: {
          articleId: { type: 'string' },
          angle:     { type: 'string' },
          tone:      { type: 'string', enum: ['ANALYTICAL', 'CRITICAL', 'EXPLANATORY'] },
          sources:   { type: 'array', items: { type: 'object' } },
        },
      },
    },
  }, async (request) => {
    const { articleId, tone } = request.body as any
    await delay(700)
    return {
      articleId,
      tone:        tone || 'ANALYTICAL',
      ...MOCK_OUTLINE,
      generatedAt: new Date().toISOString(),
    }
  })

  // POST /api/v1/ai/inline-assist
  app.post('/inline-assist', {
    schema: {
      tags: ['AI — Step 4: Drafting'],
      summary: 'Improve a selected paragraph inline',
      security: [{ bearerAuth: [] }],
      body: {
        type: 'object',
        required: ['articleId', 'paragraph'],
        properties: {
          articleId: { type: 'string' },
          paragraph: { type: 'string' },
          tone:      { type: 'string', enum: ['ANALYTICAL', 'CRITICAL', 'EXPLANATORY'] },
        },
      },
    },
  }, async (request) => {
    const { articleId, paragraph, tone } = request.body as any
    await delay(900)
    return {
      articleId,
      tone:        tone || 'ANALYTICAL',
      original:    paragraph,
      suggested:   MOCK_INLINE_ASSIST.suggested,
      rationale:   MOCK_INLINE_ASSIST.rationale,
      generatedAt: new Date().toISOString(),
    }
  })

  // POST /api/v1/ai/counterpoint
  app.post('/counterpoint', {
    schema: {
      tags: ['AI — Step 4: Drafting'],
      summary: 'Generate counterpoint for a paragraph',
      security: [{ bearerAuth: [] }],
      body: {
        type: 'object',
        required: ['articleId', 'paragraph'],
        properties: {
          articleId: { type: 'string' },
          paragraph: { type: 'string' },
        },
      },
    },
  }, async (request) => {
    const { articleId } = request.body as any
    await delay(800)
    return {
      articleId,
      ...MOCK_COUNTERPOINT,
      generatedAt: new Date().toISOString(),
    }
  })

  // ─── Step 5: Sub-editing & Optimisation ──────────────────────────────────

  // POST /api/v1/ai/sub-edit
  app.post('/sub-edit', {
    schema: {
      tags: ['AI — Step 5: Sub-editing'],
      summary: 'Run full sub-editing analysis on an article',
      security: [{ bearerAuth: [] }],
      body: {
        type: 'object',
        required: ['articleId'],
        properties: {
          articleId: { type: 'string' },
        },
      },
    },
  }, async (request) => {
    const { articleId } = request.body as any
    await delay(1200)
    return {
      articleId,
      ...MOCK_SUB_EDIT,
      generatedAt: new Date().toISOString(),
    }
  })

  // POST /api/v1/ai/seo-metadata
  app.post('/seo-metadata', {
    schema: {
      tags: ['AI — Step 5: Sub-editing'],
      summary: 'Auto-generate SEO metadata for an article',
      security: [{ bearerAuth: [] }],
      body: {
        type: 'object',
        required: ['articleId'],
        properties: {
          articleId: { type: 'string' },
        },
      },
    },
  }, async (request) => {
    const { articleId } = request.body as any
    await delay(500)
    return {
      articleId,
      ...MOCK_SEO_METADATA,
      generatedAt: new Date().toISOString(),
    }
  })

  // POST /api/v1/ai/score-headlines
  app.post('/score-headlines', {
    schema: {
      tags: ['AI — Step 5: Sub-editing'],
      summary: 'Score up to 3 headline options',
      security: [{ bearerAuth: [] }],
      body: {
        type: 'object',
        required: ['headlines'],
        properties: {
          headlines: { type: 'array', items: { type: 'string' }, minItems: 1, maxItems: 3 },
          articleId: { type: 'string' },
        },
      },
    },
  }, async (request) => {
    const { headlines, articleId } = request.body as any
    await delay(600)
    return {
      articleId:   articleId || null,
      headlines:   MOCK_HEADLINE_SCORES.headlines.slice(0, headlines.length),
      generatedAt: new Date().toISOString(),
    }
  })

  // ─── Step 6: Visual & Packaging Support ──────────────────────────────────

  // POST /api/v1/ai/packaging
  app.post('/packaging', {
    schema: {
      tags: ['AI — Step 6: Packaging'],
      summary: 'Generate image concept, pull quotes, and social captions',
      security: [{ bearerAuth: [] }],
      body: {
        type: 'object',
        required: ['articleId'],
        properties: {
          articleId: { type: 'string' },
        },
      },
    },
  }, async (request) => {
    const { articleId } = request.body as any
    await delay(1000)
    return {
      articleId,
      ...MOCK_PACKAGING,
      generatedAt: new Date().toISOString(),
    }
  })

  // POST /api/v1/ai/image-concept
  app.post('/image-concept', {
    schema: {
      tags: ['AI — Step 6: Packaging'],
      summary: 'Generate feature image concept only',
      security: [{ bearerAuth: [] }],
      body: {
        type: 'object',
        required: ['articleId'],
        properties: {
          articleId: { type: 'string' },
        },
      },
    },
  }, async (request) => {
    const { articleId } = request.body as any
    await delay(500)
    return {
      articleId,
      image_concept: MOCK_PACKAGING.image_concept,
      generatedAt:   new Date().toISOString(),
    }
  })

  // POST /api/v1/ai/social-captions
  app.post('/social-captions', {
    schema: {
      tags: ['AI — Step 6: Packaging'],
      summary: 'Generate social media captions only',
      security: [{ bearerAuth: [] }],
      body: {
        type: 'object',
        required: ['articleId'],
        properties: {
          articleId: { type: 'string' },
        },
      },
    },
  }, async (request) => {
    const { articleId } = request.body as any
    await delay(500)
    return {
      articleId,
      social_captions: MOCK_PACKAGING.social_captions,
      generatedAt:     new Date().toISOString(),
    }
  })

  // POST /api/v1/ai/pull-quotes
  app.post('/pull-quotes', {
    schema: {
      tags: ['AI — Step 6: Packaging'],
      summary: 'Extract pull quotes from article',
      security: [{ bearerAuth: [] }],
      body: {
        type: 'object',
        required: ['articleId'],
        properties: {
          articleId: { type: 'string' },
        },
      },
    },
  }, async (request) => {
    const { articleId } = request.body as any
    await delay(400)
    return {
      articleId,
      pull_quotes: MOCK_PACKAGING.pull_quotes,
      generatedAt: new Date().toISOString(),
    }
  })
}
