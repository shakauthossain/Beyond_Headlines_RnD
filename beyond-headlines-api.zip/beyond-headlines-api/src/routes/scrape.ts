import { FastifyInstance } from 'fastify'
import { triggerScrapeNow } from '../workers/queue'

export async function scrapeRoutes(app: FastifyInstance) {

  // POST /api/v1/scrape/trigger
  app.post('/trigger', {
    schema: {
      tags: ['Scrape'],
      summary: 'Manually trigger a scrape cycle',
      security: [{ bearerAuth: [] }],
      body: {
        type: 'object',
        properties: {
          sources: {
            type: 'array',
            items: { type: 'string', enum: ['PROTHOM_ALO', 'DAILY_STAR', 'BDNEWS24', 'JUGANTOR', 'DHAKA_TRIBUNE'] },
          },
        },
      },
    },
  }, async (request) => {
    const { sources } = (request.body || {}) as any
    const job = await triggerScrapeNow(sources)
    return {
      jobId:    job.id,
      status:   'QUEUED',
      sources:  sources || 'all',
      queuedAt: new Date().toISOString(),
      message:  'Scrape job queued. Clustering will follow automatically.',
    }
  })

  // GET /api/v1/scrape/status/:jobId
  app.get('/status/:jobId', {
    schema: {
      tags: ['Scrape'],
      summary: 'Get scrape job status',
      security: [{ bearerAuth: [] }],
      params: { type: 'object', properties: { jobId: { type: 'string' } } },
    },
  }, async (request) => {
    const { jobId } = request.params as { jobId: string }
    // Mock — in production query BullMQ job state
    return {
      jobId,
      status:        'COMPLETED',
      headlineCount: 47,
      clusterCount:  5,
      completedAt:   new Date().toISOString(),
    }
  })

  // GET /api/v1/scrape/last-run
  app.get('/last-run', {
    schema: {
      tags: ['Scrape'],
      summary: 'Summary of the last scrape run',
      security: [{ bearerAuth: [] }],
    },
  }, async () => ({
    lastRunAt:     new Date(Date.now() - 900000).toISOString(),
    nextRunAt:     new Date(Date.now() + 900000).toISOString(),
    headlineCount: 47,
    clusterCount:  5,
    sources: [
      { source: 'DAILY_STAR',    status: 'OK', headlineCount: 12 },
      { source: 'PROTHOM_ALO',   status: 'OK', headlineCount: 10 },
      { source: 'BDNEWS24',      status: 'OK', headlineCount: 9  },
      { source: 'JUGANTOR',      status: 'OK', headlineCount: 8  },
      { source: 'DHAKA_TRIBUNE', status: 'OK', headlineCount: 8  },
    ],
  }))
}
