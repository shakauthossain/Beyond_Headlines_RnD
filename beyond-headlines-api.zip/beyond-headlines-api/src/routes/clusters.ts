import { FastifyInstance } from 'fastify'
import { MOCK_CLUSTERS, MOCK_HEADLINES } from '../utils/mock-data'

export async function clusterRoutes(app: FastifyInstance) {

  // GET /api/v1/clusters
  // Step 1 — News Intelligence Feed
  app.get('/', {
    schema: {
      tags: ['Clusters — Step 1'],
      summary: 'Get all topic clusters (News Intelligence Feed)',
      security: [{ bearerAuth: [] }],
      querystring: {
        type: 'object',
        properties: {
          emerging: { type: 'boolean' },
        },
      },
    },
  }, async (request) => {
    const { emerging } = request.query as any
    let clusters = [...MOCK_CLUSTERS]
    if (emerging === true || emerging === 'true') {
      clusters = clusters.filter(c => c.isEmerging)
    }
    return {
      data:        clusters,
      lastUpdated: new Date().toISOString(),
      nextRefresh: new Date(Date.now() + 1800000).toISOString(),
    }
  })

  // GET /api/v1/clusters/:id
  app.get('/:id', {
    schema: {
      tags: ['Clusters — Step 1'],
      summary: 'Get cluster by ID with its headlines',
      security: [{ bearerAuth: [] }],
      params: { type: 'object', properties: { id: { type: 'string' } } },
    },
  }, async (request, reply) => {
    const { id } = request.params as { id: string }
    const cluster = MOCK_CLUSTERS.find(c => c.id === id)
    if (!cluster) return reply.status(404).send({ error: 'Cluster not found' })
    const headlines = MOCK_HEADLINES.filter(h => h.clusterId === id)
    return { ...cluster, headlines }
  })

  // GET /api/v1/clusters/headlines/raw
  app.get('/headlines/raw', {
    schema: {
      tags: ['Clusters — Step 1'],
      summary: 'Get all raw scraped headlines',
      security: [{ bearerAuth: [] }],
      querystring: {
        type: 'object',
        properties: {
          source: { type: 'string', enum: ['PROTHOM_ALO', 'DAILY_STAR', 'BDNEWS24', 'JUGANTOR', 'DHAKA_TRIBUNE'] },
        },
      },
    },
  }, async (request) => {
    const { source } = request.query as any
    let headlines = [...MOCK_HEADLINES]
    if (source) headlines = headlines.filter(h => h.source === source)
    return { data: headlines, total: headlines.length }
  })
}
