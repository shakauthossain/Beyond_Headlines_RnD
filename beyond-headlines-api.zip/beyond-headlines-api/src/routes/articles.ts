import { FastifyInstance } from 'fastify'
import { MOCK_ARTICLES } from '../utils/mock-data'

let articles = [...MOCK_ARTICLES]

export async function articleRoutes(app: FastifyInstance) {

  // GET /api/v1/articles
  app.get('/', {
    schema: {
      tags: ['Articles'],
      summary: 'List all articles',
      security: [{ bearerAuth: [] }],
      querystring: {
        type: 'object',
        properties: {
          status:     { type: 'string', enum: ['DRAFT', 'PENDING_REVIEW', 'PUBLISHED', 'ARCHIVED'] },
          categoryId: { type: 'string' },
          authorId:   { type: 'string' },
          page:       { type: 'integer', default: 1 },
          limit:      { type: 'integer', default: 20 },
        },
      },
    },
  }, async (request) => {
    const { status, categoryId, authorId, page = 1, limit = 20 } = request.query as any
    let result = [...articles]
    if (status)     result = result.filter(a => a.status === status)
    if (categoryId) result = result.filter(a => a.categoryId === categoryId)
    if (authorId)   result = result.filter(a => a.authorId === authorId)
    const start = (page - 1) * limit
    return {
      data:  result.slice(start, start + limit),
      meta:  { total: result.length, page, limit, pages: Math.ceil(result.length / limit) },
    }
  })

  // GET /api/v1/articles/:id
  app.get('/:id', {
    schema: {
      tags: ['Articles'],
      summary: 'Get article by ID',
      security: [{ bearerAuth: [] }],
      params: { type: 'object', properties: { id: { type: 'string' } } },
    },
  }, async (request, reply) => {
    const { id } = request.params as { id: string }
    const article = articles.find(a => a.id === id || a.slug === id)
    if (!article) return reply.status(404).send({ error: 'Article not found' })
    return article
  })

  // POST /api/v1/articles
  app.post('/', {
    schema: {
      tags: ['Articles'],
      summary: 'Create new article',
      security: [{ bearerAuth: [] }],
      body: {
        type: 'object',
        required: ['title'],
        properties: {
          title:      { type: 'string' },
          body:       { type: 'object' },
          categoryId: { type: 'string' },
          tone:       { type: 'string', enum: ['ANALYTICAL', 'CRITICAL', 'EXPLANATORY'] },
          angle:      { type: 'string' },
        },
      },
    },
  }, async (request, reply) => {
    const body = request.body as any
    const newArticle = {
      id:              `art-${Date.now()}`,
      title:           body.title,
      slug:            body.title.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, ''),
      body:            body.body || { type: 'doc', content: [] },
      status:          'DRAFT' as const,
      angle:           body.angle || null,
      tone:            body.tone || null,
      metaTitle:       null,
      metaDescription: null,
      tags:            [],
      publishedAt:     null,
      createdAt:       new Date().toISOString(),
      updatedAt:       new Date().toISOString(),
      authorId:        'user-editor-001',
      categoryId:      body.categoryId || null,
      author:          { id: 'user-editor-001', name: 'Editorial Analyst', email: 'editor@beyondheadlines.com' },
      category:        null,
    }
    articles.push(newArticle as any)
    return reply.status(201).send(newArticle)
  })

  // PATCH /api/v1/articles/:id
  app.patch('/:id', {
    schema: {
      tags: ['Articles'],
      summary: 'Update article',
      security: [{ bearerAuth: [] }],
      params: { type: 'object', properties: { id: { type: 'string' } } },
      body: {
        type: 'object',
        properties: {
          title:           { type: 'string' },
          body:            { type: 'object' },
          angle:           { type: 'string' },
          tone:            { type: 'string' },
          metaTitle:       { type: 'string' },
          metaDescription: { type: 'string' },
          tags:            { type: 'array', items: { type: 'string' } },
        },
      },
    },
  }, async (request, reply) => {
    const { id } = request.params as { id: string }
    const idx = articles.findIndex(a => a.id === id)
    if (idx === -1) return reply.status(404).send({ error: 'Article not found' })
    articles[idx] = { ...articles[idx], ...(request.body as any), updatedAt: new Date().toISOString() }
    return articles[idx]
  })

  // DELETE /api/v1/articles/:id
  app.delete('/:id', {
    schema: {
      tags: ['Articles'],
      summary: 'Delete article',
      security: [{ bearerAuth: [] }],
      params: { type: 'object', properties: { id: { type: 'string' } } },
    },
  }, async (request, reply) => {
    const { id } = request.params as { id: string }
    const idx = articles.findIndex(a => a.id === id)
    if (idx === -1) return reply.status(404).send({ error: 'Article not found' })
    articles.splice(idx, 1)
    return reply.status(204).send()
  })

  // GET /api/v1/articles/:id/revisions
  app.get('/:id/revisions', {
    schema: {
      tags: ['Articles'],
      summary: 'Get revision history for an article',
      security: [{ bearerAuth: [] }],
      params: { type: 'object', properties: { id: { type: 'string' } } },
    },
  }, async (request, reply) => {
    const { id } = request.params as { id: string }
    const article = articles.find(a => a.id === id)
    if (!article) return reply.status(404).send({ error: 'Article not found' })
    return {
      articleId: id,
      revisions: [
        { id: 'rev-001', savedAt: '2026-04-05T10:00:00Z', title: article.title },
        { id: 'rev-002', savedAt: '2026-04-05T11:30:00Z', title: article.title },
      ],
    }
  })

  // POST /api/v1/articles/:id/autosave
  app.post('/:id/autosave', {
    schema: {
      tags: ['Articles'],
      summary: 'Autosave article body (creates revision)',
      security: [{ bearerAuth: [] }],
      params: { type: 'object', properties: { id: { type: 'string' } } },
      body: {
        type: 'object',
        required: ['body'],
        properties: {
          body:  { type: 'object' },
          title: { type: 'string' },
        },
      },
    },
  }, async (request, reply) => {
    const { id } = request.params as { id: string }
    const { body, title } = request.body as any
    return reply.status(201).send({
      revisionId: `rev-${Date.now()}`,
      articleId:  id,
      savedAt:    new Date().toISOString(),
      title:      title || null,
    })
  })
}
