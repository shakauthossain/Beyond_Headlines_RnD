import Redis from 'ioredis'
import { config } from '../config'

export const redis = new Redis(config.REDIS_URL, {
  maxRetriesPerRequest: 3,
  retryStrategy(times) {
    if (times > 3) return null
    return Math.min(times * 200, 2000)
  },
})

redis.on('connect',  () => console.log('Redis connected'))
redis.on('error',    (err) => console.error('Redis error:', err))
redis.on('reconnecting', () => console.log('Redis reconnecting...'))
