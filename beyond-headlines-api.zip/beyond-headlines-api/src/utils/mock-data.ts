import { v4 as uuid } from 'uuid'

// ─── Users ────────────────────────────────────────────────────────────────────
export const MOCK_USERS = [
  {
    id:        'user-admin-001',
    email:     'admin@beyondheadlines.com',
    name:      'Admin User',
    role:      'ADMIN',
    createdAt: '2026-01-01T00:00:00Z',
    updatedAt: '2026-01-01T00:00:00Z',
  },
  {
    id:        'user-editor-001',
    email:     'editor@beyondheadlines.com',
    name:      'Editorial Analyst',
    role:      'EDITOR',
    createdAt: '2026-01-01T00:00:00Z',
    updatedAt: '2026-01-01T00:00:00Z',
  },
]

// ─── Categories ───────────────────────────────────────────────────────────────
export const MOCK_CATEGORIES = [
  { id: 'cat-001', name: 'Politics',   slug: 'politics',   description: 'Political analysis and commentary', parentId: null },
  { id: 'cat-002', name: 'Economy',    slug: 'economy',    description: 'Economic news and analysis',        parentId: null },
  { id: 'cat-003', name: 'Technology', slug: 'technology', description: 'Tech industry and innovation',      parentId: null },
  { id: 'cat-004', name: 'Culture',    slug: 'culture',    description: 'Society and cultural affairs',      parentId: null },
  { id: 'cat-005', name: 'Energy',     slug: 'energy',     description: 'Energy policy and crisis',          parentId: 'cat-002' },
]

// ─── Tags ─────────────────────────────────────────────────────────────────────
export const MOCK_TAGS = [
  { id: 'tag-001', name: 'Bangladesh', slug: 'bangladesh' },
  { id: 'tag-002', name: 'Inflation',  slug: 'inflation' },
  { id: 'tag-003', name: 'Election',   slug: 'election' },
  { id: 'tag-004', name: 'Budget',     slug: 'budget' },
  { id: 'tag-005', name: 'Climate',    slug: 'climate' },
]

// ─── Scraped Headlines ────────────────────────────────────────────────────────
export const MOCK_HEADLINES = [
  { id: 'h-001', source: 'DAILY_STAR',  headline: 'Bangladesh inflation hits 9.4% in March 2026', url: 'https://thedailystar.net/mock/1', category: 'Economy', scrapedAt: new Date().toISOString(), clusterId: 'cluster-001' },
  { id: 'h-002', source: 'PROTHOM_ALO', headline: 'মূল্যস্ফীতি বাড়ছে, সরকার নতুন পদক্ষেপ নিচ্ছে', url: 'https://prothomalo.com/mock/1', category: 'Economy', scrapedAt: new Date().toISOString(), clusterId: 'cluster-001' },
  { id: 'h-003', source: 'BDNEWS24',    headline: 'Fuel price hike debate intensifies in parliament', url: 'https://bdnews24.com/mock/1', category: 'Politics', scrapedAt: new Date().toISOString(), clusterId: 'cluster-002' },
  { id: 'h-004', source: 'JUGANTOR',    headline: 'বিদ্যুৎ সংকট মোকাবেলায় নতুন পরিকল্পনা', url: 'https://jugantor.com/mock/1', category: 'Energy', scrapedAt: new Date().toISOString(), clusterId: 'cluster-002' },
  { id: 'h-005', source: 'DHAKA_TRIBUNE', headline: 'Election Commission announces voter registration drive', url: 'https://dhakatribune.com/mock/1', category: 'Politics', scrapedAt: new Date().toISOString(), clusterId: 'cluster-003' },
]

// ─── Clusters ─────────────────────────────────────────────────────────────────
export const MOCK_CLUSTERS = [
  {
    id:           'cluster-001',
    topic:        'Bangladesh Inflation Crisis',
    summary:      'Rising food and fuel prices push Bangladesh inflation to record highs. Government signals new economic policy response.',
    sentiment:    'critical',
    articleCount: 14,
    isEmerging:   true,
    createdAt:    new Date().toISOString(),
  },
  {
    id:           'cluster-002',
    topic:        'Fuel Price Hike Debate',
    summary:      'Ongoing parliamentary debate over fuel subsidy removal. Energy sector faces structural reform pressure.',
    sentiment:    'neutral',
    articleCount: 9,
    isEmerging:   false,
    createdAt:    new Date().toISOString(),
  },
  {
    id:           'cluster-003',
    topic:        'Election Reform & Voter Registration',
    summary:      'Election Commission launches nationwide voter drive ahead of upcoming cycle. Reform demands continue.',
    sentiment:    'neutral',
    articleCount: 6,
    isEmerging:   false,
    createdAt:    new Date().toISOString(),
  },
]

// ─── Articles ─────────────────────────────────────────────────────────────────
export const MOCK_ARTICLES = [
  {
    id:              'art-001',
    title:           'The inflation trap: why Bangladesh\'s economic policy is failing ordinary citizens',
    slug:            'inflation-trap-bangladesh-economic-policy',
    body:            { type: 'doc', content: [] },
    status:          'PUBLISHED',
    angle:           'Economic impact vs political narrative',
    tone:            'ANALYTICAL',
    metaTitle:       'Bangladesh Inflation Crisis — Analysis',
    metaDescription: 'A deep analysis of Bangladesh\'s inflation crisis and why current economic policy is struggling.',
    tags:            ['Bangladesh', 'Inflation', 'Economy'],
    publishedAt:     '2026-04-01T10:00:00Z',
    createdAt:       '2026-03-28T08:00:00Z',
    updatedAt:       '2026-04-01T09:30:00Z',
    authorId:        'user-editor-001',
    categoryId:      'cat-002',
    author:          { id: 'user-editor-001', name: 'Editorial Analyst', email: 'editor@beyondheadlines.com' },
    category:        { id: 'cat-002', name: 'Economy', slug: 'economy' },
  },
  {
    id:              'art-002',
    title:           'Fuel subsidies and the politics of energy reform',
    slug:            'fuel-subsidies-politics-energy-reform',
    body:            { type: 'doc', content: [] },
    status:          'DRAFT',
    angle:           'Political resistance to structural reform',
    tone:            'CRITICAL',
    metaTitle:       null,
    metaDescription: null,
    tags:            [],
    publishedAt:     null,
    createdAt:       '2026-04-04T09:00:00Z',
    updatedAt:       '2026-04-05T14:00:00Z',
    authorId:        'user-editor-001',
    categoryId:      'cat-005',
    author:          { id: 'user-editor-001', name: 'Editorial Analyst', email: 'editor@beyondheadlines.com' },
    category:        { id: 'cat-005', name: 'Energy', slug: 'energy' },
  },
]

// ─── Research Sessions ────────────────────────────────────────────────────────
export const MOCK_RESEARCH = {
  id:        'research-001',
  articleId: 'art-002',
  angle:     'Fuel Price Hike Debate — Economic impact vs political narrative',
  sources: [
    { headline: 'Bangladesh fuel prices among highest in South Asia', url: 'https://thedailystar.net/mock/fuel-1', summary: 'Bangladesh fuel prices have risen 40% in 18 months amid global supply pressures.', credibility_tier: 1 },
    { headline: 'IMF urges subsidy reform for Bangladesh fiscal stability', url: 'https://bbc.com/mock/imf', summary: 'IMF conditions for loan disbursement include energy subsidy reduction targets.', credibility_tier: 2 },
  ],
  timeline: [
    { date: '2022-08', event: 'Government raises fuel prices by 51% in a single move', source: 'Daily Star' },
    { date: '2023-03', event: 'Second fuel price adjustment — 5% increase', source: 'BDNews24' },
    { date: '2024-01', event: 'Parliament debates full subsidy removal proposal', source: 'Dhaka Tribune' },
    { date: '2026-04', event: 'Current debate intensifies ahead of budget cycle', source: 'Prothom Alo' },
  ],
  dataPoints: [
    'Fuel subsidy bill reached USD 4.2 billion in FY2024',
    '67% of Bangladeshi households report fuel cost as primary financial pressure',
    'Bangladesh energy subsidy as % of GDP: 2.1% vs regional average of 0.8%',
  ],
  gaps: [
    'No independent analysis of subsidy reform impact on rural transport costs',
    'Limited coverage of opposition party\'s alternative proposal',
    'Missing data on informal sector energy dependency',
  ],
  createdAt: new Date().toISOString(),
}

// ─── AI Mock Outputs ──────────────────────────────────────────────────────────
export const MOCK_TOPIC_BRIEF = {
  issue_summary: 'Bangladesh is experiencing a sustained fuel price debate driven by IMF reform conditions, government fiscal pressures, and public resistance. The debate has shifted from technical energy policy into a politically charged question about the cost of living.',
  key_questions: [
    'Who bears the cost of subsidy removal — consumers or industry?',
    'Is the government\'s reform timeline driven by economics or electoral calculation?',
    'What alternatives exist beyond full subsidy removal?',
  ],
  stakeholders: [
    { name: 'Ministry of Finance', role: 'Driving reform for IMF compliance' },
    { name: 'Bangladesh Energy Regulatory Commission', role: 'Setting official price adjustments' },
    { name: 'Opposition parties', role: 'Resisting reform, demanding price rollback' },
    { name: 'IMF Bangladesh mission', role: 'Conditioning loan release on subsidy targets' },
    { name: 'Transport workers unions', role: 'Protesting downstream cost impact' },
  ],
  viewpoints: [
    'Reform is necessary for long-term fiscal sustainability and foreign reserve stability',
    'Abrupt subsidy removal disproportionately impacts low-income households and informal workers',
    'Phased subsidy reform with targeted social protection is a viable middle path',
  ],
}

export const MOCK_OUTLINE = {
  sections: [
    { label: 'Introduction', direction: 'Frame the fuel price debate as a political and economic fault line, not just a policy question.' },
    { label: 'Context', direction: 'Explain the history of Bangladesh fuel subsidies, the 2022 shock increase, and IMF conditions.' },
    { label: 'Analysis', direction: 'Examine the competing forces: government fiscal need, public resistance, and international pressure.' },
    { label: 'Conclusion', direction: 'Assess what the debate reveals about Bangladesh\'s broader economic governance challenges.' },
  ],
}

export const MOCK_SUB_EDIT = {
  clarity_issues: [
    { paragraph_index: 2, issue_description: 'Passive voice weakens the argument', suggested_fix: 'Rewrite "prices were raised" as "the government raised prices"' },
    { paragraph_index: 5, issue_description: 'Sentence too long — splits reader attention', suggested_fix: 'Break into two sentences at the conjunction' },
  ],
  tone_issues: [
    { paragraph_index: 3, issue_description: 'Tone shifts from analytical to opinion without signalling', suggested_fix: 'Add "this analysis suggests" to anchor the claim' },
  ],
  flow_issues: [
    { paragraph_index: 4, issue_description: 'Abrupt transition from historical context to current debate', suggested_fix: 'Add a bridging sentence referencing the 2022 price shock' },
  ],
}

export const MOCK_SEO_METADATA = {
  meta_title:       'Bangladesh Fuel Subsidy Debate 2026: Politics vs Economics',
  meta_description: 'An analytical breakdown of Bangladesh\'s ongoing fuel price debate — examining the IMF conditions, government strategy, and the human cost of reform.',
  tags:             ['Bangladesh', 'fuel subsidy', 'energy reform', 'IMF', 'inflation'],
}

export const MOCK_HEADLINE_SCORES = {
  headlines: [
    { headline: 'The fuel trap: how Bangladesh got stuck between reform and revolt', score: 9, rationale: 'Strong metaphor, clear tension, SEO-friendly keywords, fits analytical tone' },
    { headline: 'Bangladesh fuel prices: what the debate is really about', score: 7, rationale: 'Conversational, accessible, but lacks specificity and editorial weight' },
    { headline: 'Fuel subsidy removal and its political consequences in Bangladesh', score: 6, rationale: 'Accurate but dry — reads like a report title, not an editorial headline' },
  ],
}

export const MOCK_PACKAGING = {
  image_concept: 'A split-frame visual: on one side, a fuel pump with a rising price display; on the other, a busy Dhaka street market with people haggling. Muted tones with a deep blue accent. No text overlay. Conveys economic pressure in an urban South Asian context.',
  pull_quotes: [
    { quote: 'The debate has shifted from technical energy policy into a politically charged question about the cost of living.', paragraph_index: 1 },
    { quote: 'What the debate reveals about Bangladesh\'s broader economic governance challenges.', paragraph_index: 7 },
  ],
  social_captions: {
    twitter:  'Bangladesh\'s fuel subsidy debate isn\'t really about fuel. It\'s about who pays the price of reform — and who decides. New analysis: [link]',
    linkedin: 'Our latest analysis examines Bangladesh\'s fuel subsidy crisis — the IMF conditions, the political resistance, and the households caught in between. A deep-dive into economic governance under pressure.',
    whatsapp: 'Beyond Headlines: Why the Bangladesh fuel price debate matters — not just for energy, but for the entire economic direction of the country. Worth reading.',
  },
}

export const MOCK_INLINE_ASSIST = {
  original:  'The government has been under pressure from the IMF to reduce fuel subsidies.',
  suggested: 'IMF loan conditions have placed the government in a difficult position: reduce fuel subsidies or risk delayed disbursements that Bangladesh\'s foreign reserves can ill afford.',
  rationale: 'Strengthened the causal chain and added specificity about the stakes, maintaining analytical tone.',
}

export const MOCK_COUNTERPOINT = {
  counterpoint: 'Fuel subsidy reform is a necessary and overdue correction that protects Bangladesh\'s long-term fiscal stability.',
  supporting_points: [
    'Subsidy spending crowds out investment in health, education, and infrastructure',
    'Market-priced fuel encourages energy efficiency and reduces waste',
    'Targeted cash transfers can protect vulnerable households more efficiently than broad subsidies',
    'Continued subsidies have contributed to foreign reserve pressure and import bills',
  ],
}

// ─── Media ────────────────────────────────────────────────────────────────────
export const MOCK_MEDIA = [
  { id: 'media-001', filename: 'bangladesh-fuel-pump.jpg', url: 'https://cdn.beyondheadlines.com/mock/img1.jpg', mimeType: 'image/jpeg', size: 245000, alt: 'Fuel pump in Dhaka', uploadedAt: '2026-04-01T08:00:00Z' },
  { id: 'media-002', filename: 'inflation-chart-q1-2026.png', url: 'https://cdn.beyondheadlines.com/mock/img2.png', mimeType: 'image/png', size: 89000, alt: 'Bangladesh inflation chart Q1 2026', uploadedAt: '2026-04-02T10:00:00Z' },
]

// ─── Analytics ────────────────────────────────────────────────────────────────
export const MOCK_ANALYTICS = {
  overview: {
    totalArticles:     42,
    publishedArticles: 28,
    draftArticles:     11,
    totalPageViews:    18420,
    avgReadTime:       '4m 32s',
    topCategory:       'Economy',
  },
  topArticles: [
    { slug: 'inflation-trap-bangladesh-economic-policy', title: 'The inflation trap', views: 4210, avgReadTime: '5m 12s' },
    { slug: 'fuel-subsidies-politics-energy-reform', title: 'Fuel subsidies and the politics of energy reform', views: 2890, avgReadTime: '4m 01s' },
  ],
  trafficByDay: [
    { date: '2026-04-01', views: 1240 },
    { date: '2026-04-02', views: 980 },
    { date: '2026-04-03', views: 1540 },
    { date: '2026-04-04', views: 2100 },
    { date: '2026-04-05', views: 1880 },
    { date: '2026-04-06', views: 2310 },
  ],
}
