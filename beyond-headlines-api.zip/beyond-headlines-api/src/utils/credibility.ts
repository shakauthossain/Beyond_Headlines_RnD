const TIER_1_DOMAINS = [
  'thedailystar.net',
  'prothomalo.com',
  'bdnews24.com',
  'jugantor.com',
  'dhakatribune.com',
]

export const getCredibilityTier = (url: string): 1 | 2 =>
  TIER_1_DOMAINS.some((domain) => url.includes(domain)) ? 1 : 2

export const getCredibilityLabel = (tier: 1 | 2): string =>
  tier === 1 ? 'Trusted Source' : 'General Web'
