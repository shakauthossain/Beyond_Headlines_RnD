import Anthropic from '@anthropic-ai/sdk'
import { z } from 'zod'
import { config } from '../config'
import { retryOnce } from '../utils/retry'
import {
  ClusterSchema,
  TopicBriefSchema,
  ResearchSynthesisSchema,
  SEOMetadataSchema,
  SubEditSchema,
  HeadlineScoreSchema,
  PackagingSchema,
  OutlineSchema,
  InlineAssistSchema,
  CounterpointSchema,
} from '../types/ai.types'

const anthropic = new Anthropic({ apiKey: config.ANTHROPIC_API_KEY })

// ─── Core call wrapper ────────────────────────────────────────────────────────
async function callClaude<T>(
  model: string,
  system: string,
  user: string,
  schema: z.ZodType<T>,
  maxTokens = 1000
): Promise<T> {
  const _call = async (prompt: string): Promise<T> => {
    const response = await anthropic.messages.create({
      model,
      max_tokens: maxTokens,
      system,
      messages: [{ role: 'user', content: prompt }],
    })
    const raw = (response.content[0] as { text: string }).text
      .trim()
      .replace(/^```json|```$/g, '')
      .trim()
    return schema.parse(JSON.parse(raw))
  }
  try {
    return await _call(user)
  } catch {
    return await retryOnce(() =>
      _call(user + '\n\nRespond with valid JSON only. No preamble. No markdown fences.')
    )
  }
}

// ─── Step 1 — Cluster headlines ───────────────────────────────────────────────
export async function clusterHeadlines(headlines: string[]) {
  return callClaude(
    config.CLAUDE_HAIKU_MODEL,
    'You are an editorial analyst. Group the following headlines into topic clusters. Return ONLY a JSON array, no preamble.',
    `Headlines:\n${JSON.stringify(headlines)}\n\nReturn: [{"topic":"...","summary":"...","sentiment":"critical|neutral|supportive","article_count":N,"is_emerging":false}]`,
    z.array(ClusterSchema)
  )
}

// ─── Step 2 — Topic brief & framing ──────────────────────────────────────────
export async function generateTopicBrief(clusterSummary: string, headlines: string[]) {
  return callClaude(
    config.CLAUDE_SONNET_MODEL,
    'You are a senior editorial analyst. Produce a structured topic brief in JSON. No preamble.',
    `Topic: ${clusterSummary}\nHeadlines: ${JSON.stringify(headlines)}\n\nReturn: {"issue_summary":"...","key_questions":["..."],"stakeholders":[{"name":"...","role":"..."}],"viewpoints":["..."]}`,
    TopicBriefSchema,
    1000
  )
}

// ─── Step 3 — Perplexity web search ──────────────────────────────────────────
export async function searchPerplexity(query: string): Promise<{ url: string; snippet: string }[]> {
  const response = await fetch('https://api.perplexity.ai/chat/completions', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${config.PERPLEXITY_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: 'llama-3.1-sonar-large-128k-online',
      messages: [{ role: 'user', content: query }],
      return_citations: true,
    }),
  })
  const data = await response.json()
  return data.citations ?? []
}

// ─── Step 3 — Research synthesis ─────────────────────────────────────────────
export async function synthesiseResearch(angle: string, sources: object[]) {
  return callClaude(
    config.CLAUDE_HAIKU_MODEL,
    'You are a research analyst. Synthesise the following sources into a structured report. Return ONLY valid JSON.',
    `Angle: ${angle}\nSources: ${JSON.stringify(sources)}\n\nReturn: {"timeline":[{"date":"...","event":"...","source":"..."}],"data_points":["..."],"gaps":["..."]}`,
    ResearchSynthesisSchema,
    1000
  )
}

// ─── Step 4 — Article outline ────────────────────────────────────────────────
export async function generateOutline(angle: string, tone: string, sources: object[]) {
  return callClaude(
    config.CLAUDE_SONNET_MODEL,
    `You are a senior editorial writer. Generate a structured article outline. Tone: ${tone}. Return ONLY valid JSON.`,
    `Angle: ${angle}\nSources summary: ${JSON.stringify(sources.slice(0, 3))}\n\nReturn: {"sections":[{"label":"Introduction","direction":"..."},{"label":"Context","direction":"..."},{"label":"Analysis","direction":"..."},{"label":"Conclusion","direction":"..."}]}`,
    OutlineSchema,
    800
  )
}

// ─── Step 4 — Inline paragraph assist ────────────────────────────────────────
export async function inlineAssist(paragraph: string, tone: string, articleContext: string) {
  return callClaude(
    config.CLAUDE_SONNET_MODEL,
    `You are a sub-editor. Improve the given paragraph while preserving the author's voice. Tone: ${tone}. Return ONLY valid JSON.`,
    `Paragraph: ${paragraph}\nArticle context: ${articleContext}\n\nReturn: {"original":"...","suggested":"...","rationale":"..."}`,
    InlineAssistSchema,
    600
  )
}

// ─── Step 4 — Counterpoint ───────────────────────────────────────────────────
export async function generateCounterpoint(paragraph: string) {
  return callClaude(
    config.CLAUDE_SONNET_MODEL,
    'You are an editorial analyst. Steelman the opposing position to the argument in the paragraph. Return ONLY valid JSON.',
    `Paragraph: ${paragraph}\n\nReturn: {"counterpoint":"...","supporting_points":["..."]}`,
    CounterpointSchema,
    600
  )
}

// ─── Step 5 — Sub-editing ────────────────────────────────────────────────────
export async function subEditArticle(articleText: string, brandVoice: string) {
  return callClaude(
    config.CLAUDE_SONNET_MODEL,
    `You are a professional sub-editor. Analyse the article for editorial issues. Brand voice: ${brandVoice}. Return ONLY valid JSON.`,
    `Article:\n${articleText}\n\nReturn: {"clarity_issues":[{"paragraph_index":0,"issue_description":"...","suggested_fix":"..."}],"tone_issues":[...],"flow_issues":[...]}`,
    SubEditSchema,
    1500
  )
}

// ─── Step 5 — Headline scoring ───────────────────────────────────────────────
export async function scoreHeadlines(headlines: string[]) {
  return callClaude(
    config.CLAUDE_SONNET_MODEL,
    'You are an editorial headline analyst. Score each headline on clarity, SEO strength, and brand voice fit. Return ONLY valid JSON.',
    `Headlines: ${JSON.stringify(headlines)}\n\nReturn: {"headlines":[{"headline":"...","score":8,"rationale":"..."}]}`,
    HeadlineScoreSchema,
    600
  )
}

// ─── Step 5 — SEO metadata ───────────────────────────────────────────────────
export async function generateSEOMetadata(title: string, intro: string) {
  return callClaude(
    config.CLAUDE_HAIKU_MODEL,
    'You are an SEO specialist. Generate metadata from the article content. Return ONLY valid JSON.',
    `Title: ${title}\nIntro: ${intro}\n\nReturn: {"meta_title":"...","meta_description":"...","tags":["..."]}`,
    SEOMetadataSchema,
    400
  )
}

// ─── Step 6 — Packaging ──────────────────────────────────────────────────────
export async function generatePackaging(title: string, articleSummary: string) {
  return callClaude(
    config.CLAUDE_HAIKU_MODEL,
    'You are an editorial packaging specialist. Generate visual and social media packaging. Return ONLY valid JSON.',
    `Title: ${title}\nSummary: ${articleSummary}\n\nReturn: {"image_concept":"...","pull_quotes":[{"quote":"...","paragraph_index":0}],"social_captions":{"twitter":"...","linkedin":"...","whatsapp":"..."}}`,
    PackagingSchema,
    800
  )
}
