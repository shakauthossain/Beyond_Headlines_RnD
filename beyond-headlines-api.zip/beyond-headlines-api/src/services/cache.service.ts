import { getCached, setCached, deleteCached, makeKey } from '../redis/cache'
import { config } from '../config'

export async function getCachedCluster(headlines: string[]) {
  const key = makeKey('cluster', JSON.stringify(headlines.sort()))
  return getCached(key)
}

export async function setCachedCluster(headlines: string[], data: unknown) {
  const key = makeKey('cluster', JSON.stringify(headlines.sort()))
  return setCached(key, data, config.CLUSTER_CACHE_TTL)
}

export async function getCachedResearch(angle: string) {
  const key = makeKey('research', angle)
  return getCached(key)
}

export async function setCachedResearch(angle: string, data: unknown) {
  const key = makeKey('research', angle)
  return setCached(key, data, config.RESEARCH_CACHE_TTL)
}

export async function invalidateClusterCache(headlines: string[]) {
  const key = makeKey('cluster', JSON.stringify(headlines.sort()))
  return deleteCached(key)
}
