export interface PublishChecklist {
  titleSet:        boolean
  metaDescription: boolean
  imageConcept:    boolean
  tagsAdded:       boolean
}

export interface ChecklistResult {
  valid:   boolean
  missing: string[]
  items:   Record<string, { passed: boolean; label: string }>
}

export function validateChecklist(checklist: PublishChecklist): ChecklistResult {
  const items = {
    titleSet:        { passed: checklist.titleSet,        label: 'Headline set' },
    metaDescription: { passed: checklist.metaDescription, label: 'Meta description filled' },
    imageConcept:    { passed: checklist.imageConcept,    label: 'Feature image concept saved' },
    tagsAdded:       { passed: checklist.tagsAdded,       label: 'At least one tag added' },
  }
  const missing = Object.entries(items)
    .filter(([, v]) => !v.passed)
    .map(([, v]) => v.label)

  return { valid: missing.length === 0, missing, items }
}

export function generateSlug(title: string): string {
  return title
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .trim()
}
