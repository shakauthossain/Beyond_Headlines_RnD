import * as cheerio from 'cheerio'
import { getCredibilityTier } from '../utils/credibility'

export interface ScrapedItem {
  source:    string
  headline:  string
  url:       string
  category?: string
}

const SOURCES: Record<string, { url: string; selector: string; jsRendered: boolean }> = {
  DAILY_STAR:    { url: 'https://www.thedailystar.net',  selector: 'h3.title a, h2.title a', jsRendered: false },
  PROTHOM_ALO:   { url: 'https://www.prothomalo.com',    selector: 'h2 a, h3 a',              jsRendered: true  },
  BDNEWS24:      { url: 'https://bdnews24.com',          selector: 'h5.news-card-title a',    jsRendered: false },
  JUGANTOR:      { url: 'https://www.jugantor.com',      selector: '.news-title a, h2 a',     jsRendered: false },
  DHAKA_TRIBUNE: { url: 'https://www.dhakatribune.com',  selector: 'h3 a, h2.title a',        jsRendered: false },
}

export async function scrapeSource(sourceKey: string): Promise<ScrapedItem[]> {
  const sourceConfig = SOURCES[sourceKey]
  if (!sourceConfig) throw new Error(`Unknown source: ${sourceKey}`)

  if (sourceConfig.jsRendered) {
    return scrapeWithPlaywright(sourceKey, sourceConfig)
  }
  return scrapeWithCheerio(sourceKey, sourceConfig)
}

export async function scrapeAllSources(): Promise<ScrapedItem[]> {
  const results = await Promise.allSettled(
    Object.keys(SOURCES).map((key) => scrapeSource(key))
  )
  const allItems: ScrapedItem[] = []
  results.forEach((result, idx) => {
    if (result.status === 'fulfilled') {
      allItems.push(...result.value)
    } else {
      console.error(`Scrape failed for ${Object.keys(SOURCES)[idx]}:`, result.reason)
    }
  })
  return allItems
}

async function scrapeWithCheerio(sourceKey: string, cfg: { url: string; selector: string }): Promise<ScrapedItem[]> {
  const response = await fetch(cfg.url, {
    headers: { 'User-Agent': 'Mozilla/5.0 (compatible; BeyondHeadlinesBot/1.0)' },
    signal: AbortSignal.timeout(10000),
  })
  const html = await response.text()
  const $ = cheerio.load(html)
  const items: ScrapedItem[] = []
  $(cfg.selector).slice(0, 30).each((_, el) => {
    const headline = $(el).text().trim()
    const href     = $(el).attr('href') || ''
    const url      = href.startsWith('http') ? href : `${new URL(cfg.url).origin}${href}`
    if (headline && url) {
      items.push({ source: sourceKey, headline, url })
    }
  })
  return items
}

async function scrapeWithPlaywright(sourceKey: string, cfg: { url: string; selector: string }): Promise<ScrapedItem[]> {
  // Playwright import is dynamic to avoid loading the browser unless needed
  try {
    const { chromium } = await import('playwright')
    const browser = await chromium.launch({ headless: true })
    const page    = await browser.newPage()
    await page.goto(cfg.url, { timeout: 15000 })
    await page.waitForLoadState('networkidle')
    const elements = await page.$$(cfg.selector)
    const items: ScrapedItem[] = []
    for (const el of elements.slice(0, 30)) {
      const headline = (await el.innerText()).trim()
      const url      = (await el.getAttribute('href')) ?? ''
      if (headline && url) {
        items.push({ source: sourceKey, headline, url: url.startsWith('http') ? url : `${new URL(cfg.url).origin}${url}` })
      }
    }
    await browser.close()
    return items
  } catch (err) {
    console.error(`Playwright scrape failed for ${sourceKey}, falling back to cheerio:`, err)
    return scrapeWithCheerio(sourceKey, cfg)
  }
}
