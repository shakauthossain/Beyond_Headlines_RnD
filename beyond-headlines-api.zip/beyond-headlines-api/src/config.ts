import dotenv from 'dotenv'
dotenv.config()

export const config = {
  PORT: Number(process.env.PORT) || 8000,
  NODE_ENV: process.env.NODE_ENV || 'development',
  DATABASE_URL: process.env.DATABASE_URL || '',
  REDIS_URL: process.env.REDIS_URL || 'redis://localhost:6379',
  ANTHROPIC_API_KEY: process.env.ANTHROPIC_API_KEY || '',
  PERPLEXITY_API_KEY: process.env.PERPLEXITY_API_KEY || '',
  CLAUDE_SONNET_MODEL: process.env.CLAUDE_SONNET_MODEL || 'claude-sonnet-4-5',
  CLAUDE_HAIKU_MODEL: process.env.CLAUDE_HAIKU_MODEL || 'claude-haiku-4-5-20251001',
  JWT_SECRET: process.env.JWT_SECRET || 'dev-secret',
  SCRAPE_INTERVAL_MS: Number(process.env.SCRAPE_INTERVAL_MS) || 1800000,
  CLUSTER_CACHE_TTL: Number(process.env.CLUSTER_CACHE_TTL) || 1800,
  RESEARCH_CACHE_TTL: Number(process.env.RESEARCH_CACHE_TTL) || 7200,
}
